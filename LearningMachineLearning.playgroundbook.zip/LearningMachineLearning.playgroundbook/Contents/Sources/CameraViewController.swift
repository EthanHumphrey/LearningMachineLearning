//
//  CameraViewController.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 2/26/19.
//

import UIKit
import AVFoundation
import PlaygroundSupport
import CoreML
import Vision

public class CameraViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, PlaygroundLiveViewMessageHandler {
    
    // MARK: - Variables
    // MARK: AVFoundation Variables
    var captureSession: AVCaptureSession!
    var videoOutput: AVCaptureVideoDataOutput!
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    
    var timeBetweenPredictions = 0.5
    
    // MARK: CoreML Variables
    var selectedModel: MLModelInfo!
    var customModel: VNCoreMLModel!
    var modelTypeClassName: String!
    var defaultModels = [MLModelInfo]()
    
    var timeOfLastCheck = Date()
    var lastTypeDetected = ""
    var readOutPrediction = false
    
    var confidenceThreshold: Float = 85.0
    
    // MARK: Playground Communication Variables
    public var currentPlaygroundOptions: [PlaygroundCameraOptions] = [.all]
    var showPredictions = true
    
    // MARK: - UI Elements
    var cameraPreviewView: UIView = UIView()
    
    let topBlurView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let visualEffectView = UIVisualEffectView(effect: blurEffect)
        visualEffectView.layer.cornerRadius = 20
        visualEffectView.clipsToBounds = true
        return visualEffectView
    }()
    
    let modelNameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 25, weight: .semibold)
        label.text = "Model Name"
        label.accessibilityLabel = "Currently Selected Model"
        label.textAlignment = .center
        return label
    }()
    
    let modelInfoButton: UIButton = {
        let button = UIButton()
        button.accessibilityLabel = "Model Info"
        button.accessibilityHint = "View more info about the currently selected model."
        button.setImage(#imageLiteral(resourceName: "infoButton.png").withRenderingMode(.alwaysTemplate), for: .normal)
        button.bounds = CGRect(x: 0, y: 0, width: 30, height: 30)
        button.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.2)
        button.addTarget(self, action: #selector(infoButtonPressed(sender:)), for: .touchUpInside)
        return button
    }()
    
    let changeModelButton: UIButton = {
        let button = UIButton()
        button.accessibilityLabel = "Change Model"
        button.accessibilityHint = "Change the currently selected model to identify different types of objects."
        button.setImage(#imageLiteral(resourceName: "changeModelButton.png").withRenderingMode(.alwaysTemplate), for: .normal)
        button.bounds = CGRect(x: 0, y: 0, width: 30, height: 30)
        button.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.2)
        button.addTarget(self, action: #selector(changeModelButtonPressed(sender:)), for: .touchUpInside)
        return button
    }()
    
    let bottomBlurView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let visualEffectView = UIVisualEffectView(effect: blurEffect)
        visualEffectView.layer.cornerRadius = 20
        visualEffectView.clipsToBounds = true
        return visualEffectView
    }()
    
    let predictedClassLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 25, weight: .semibold)
        label.text = "Predicted Category"
        label.accessibilityElementsHidden = true
        label.textAlignment = .center
        return label
    }()
    
    let actualClassLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 32, weight: .bold)
        label.text = "Nothing Recognized"
        label.accessibilityLabel = "Predicted Category"
        label.textAlignment = .center
        return label
    }()
    
    let probabilityLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 25, weight: .medium)
        label.text = "--% Confident"
        label.textAlignment = .center
        return label
    }()
    
    let voiceOverBlurView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let visualEffectView = UIVisualEffectView(effect: blurEffect)
        visualEffectView.layer.cornerRadius = 20
        visualEffectView.clipsToBounds = true
        return visualEffectView
    }()
    
    let voiceOverLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        label.text = "VoiceOver Readout: "
        label.textAlignment = .left
        label.accessibilityElementsHidden = true
        return label
    }()
    
    let voiceOverSwitch: UISwitch = {
        let voiceOverSwitch = UISwitch()
        voiceOverSwitch.isOn = false
        voiceOverSwitch.addTarget(self, action: #selector(voiceOverSwitchedChanged(sender:)), for: .touchUpInside)
        voiceOverSwitch.accessibilityLabel = "VoiceOver Readout"
        voiceOverSwitch.accessibilityHint = "Toggle this to get a readout any time the app detects a new type of object."
        return voiceOverSwitch
    }()
    
    // MARK: - Initial Setup
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Set Up UI
        cameraPreviewView = UIView()
        cameraPreviewView.backgroundColor = UIColor.black
        self.view.addSubview(cameraPreviewView)
        UIHelper.createConstraints(between: cameraPreviewView, and: self.view, constant: 0)
        
        // Top View
        self.view.addSubview(topBlurView)
        UIHelper.createConstraints([.top, .left, .right], between: topBlurView, and: self.view, constant: 30)
        UIHelper.createHeightConstraint(75, for: topBlurView)
        
        topBlurView.contentView.addSubview(modelNameLabel)
        UIHelper.createConstraints([.centerX, .centerY], between: modelNameLabel, and: topBlurView.contentView, constant: 0)
        
        topBlurView.contentView.addSubview(modelInfoButton)
        UIHelper.createConstraints([.left], between: modelInfoButton, and: topBlurView.contentView, constant: 16)
        UIHelper.createConstraints([.centerY], between: modelInfoButton, and: topBlurView.contentView, constant: 0)
        UIHelper.createHeightConstraint(30, for: modelInfoButton)
        UIHelper.createWidthConstraint(30, for: modelInfoButton)
        
        topBlurView.contentView.addSubview(changeModelButton)
        UIHelper.createConstraints([.right], between: changeModelButton, and: topBlurView.contentView, constant: 16)
        UIHelper.createConstraints([.centerY], between: changeModelButton, and: topBlurView.contentView, constant: 0)
        UIHelper.createHeightConstraint(30, for: changeModelButton)
        UIHelper.createWidthConstraint(30, for: changeModelButton)
        
        UIHelper.layout(view: changeModelButton, rightOf: modelNameLabel, distance: -8)
        UIHelper.layout(view: modelInfoButton, leftOf: modelNameLabel, distance: -8)
        
        // Bottom View
        self.view.addSubview(bottomBlurView)
        UIHelper.createConstraints([.left, .right, .bottom], between: bottomBlurView, and: self.view, constant: 30)
        UIHelper.createHeightConstraint(150, for: bottomBlurView)
        
        bottomBlurView.contentView.addSubview(predictedClassLabel)
        UIHelper.createConstraints([.top, .left, .right], between: predictedClassLabel, and: bottomBlurView.contentView, constant: 16)
        
        bottomBlurView.contentView.addSubview(actualClassLabel)
        UIHelper.createConstraints([.centerX, .centerY], between: actualClassLabel, and: bottomBlurView.contentView, constant: 0)
        UIHelper.createConstraints([.right, .left], between: actualClassLabel, and: bottomBlurView.contentView, constant: 16)
        
        bottomBlurView.contentView.addSubview(probabilityLabel)
        UIHelper.createConstraints([.bottom, .left, .right], between: probabilityLabel, and: bottomBlurView.contentView, constant: 16)
        
        // Set up models
        
        var oldCustomModelName = "Writing Tools Classifier"
        var oldAuthorName: String?
        
        if let keyValue = PlaygroundKeyValueStore.current["writingToolsName"],
            case .string(let modelName) = keyValue {
            oldCustomModelName = modelName
        }
        if let keyValue = PlaygroundKeyValueStore.current["writingToolsAuthor"],
            case .string(let modelAuthorName) = keyValue {
            oldAuthorName = modelAuthorName
        }
        
        var customModelName = "Fruit Classifier"
        var authorName: String?
        
        if let keyValue = PlaygroundKeyValueStore.current["fruitModelName"],
            case .string(let modelName) = keyValue {
            customModelName = modelName
        }
        if let keyValue = PlaygroundKeyValueStore.current["fruitModelAuthor"],
            case .string(let modelAuthorName) = keyValue {
            authorName = modelAuthorName
        }
        
        let dogModelURL = Bundle.main.url(forResource: "DogClassifier", withExtension: "mlmodelc")!
        let dogModelInfo = MLModelInfo(modelName: "Dog Breed Classifier", modelURL: dogModelURL, isCompiled: true, classNames: ["Chihuahua", "Cocker Spaniel", "Dalmation", "German Shepherd", "Golden Retriever", "Greyhound", "Labrador Retriever", "Poodle", "Pug", "Shih Tzu"], confidenceThreshold: 70.0)
        
        let yourModelURL = Bundle.main.url(forResource: "WritingToolsClassifier", withExtension: "mlmodelc")!
        var writingToolsModelInfo = MLModelInfo(modelName: oldCustomModelName, modelURL: yourModelURL, isCompiled: true, classNames: ["Apple Pencil", "Mechanical Pencil", "Pen", "Pencil"], confidenceThreshold: 80.0)
        writingToolsModelInfo.setAuthorName(oldAuthorName)
        
        let fruitModelURL = Bundle.main.url(forResource: "FruitClassifier", withExtension: "mlmodelc")!
        var fruitModelInfo = MLModelInfo(modelName: customModelName, modelURL: fruitModelURL, isCompiled: true, classNames: ["Apple", "Banana", "Grape", "Orange", "Strawberry"], confidenceThreshold: 85.0)
        fruitModelInfo.setAuthorName(authorName)
        
        defaultModels = [dogModelInfo, writingToolsModelInfo, fruitModelInfo]
        
        // Default Dog Model
        if customModel == nil {
            changeModel(model: defaultModels[0])
        }
        
        // Initial VoiceOver Setup
        
        voiceOverBlurView.contentView.addSubview(voiceOverLabel)
        UIHelper.createConstraints([.left, .top, .bottom], between: voiceOverLabel, and: voiceOverBlurView.contentView, constant: 16)
        voiceOverBlurView.contentView.addSubview(voiceOverSwitch)
        UIHelper.createConstraints([.right], between: voiceOverSwitch, and: voiceOverBlurView.contentView, constant: 16)
        UIHelper.createConstraints([.centerY], between: voiceOverSwitch, and: voiceOverBlurView.contentView, constant: 0)
        UIHelper.layout(view: voiceOverSwitch, rightOf: voiceOverLabel, distance: 8)
        
        setUpVoiceOver()
        
        NotificationCenter.default.addObserver(self, selector: #selector(setUpVoiceOver), name: UIAccessibility.voiceOverStatusDidChangeNotification, object: nil)
    }
    
    @objc func setUpVoiceOver() {
        if UIAccessibility.isVoiceOverRunning {
            timeBetweenPredictions = 3
            UIAccessibility.post(notification: .announcement, argument: "Begin Scanning For Objects")
            voiceOverBlurView.alpha = 0
            self.view.addSubview(voiceOverBlurView)
            UIHelper.createHeightConstraint(50, for: voiceOverBlurView)
            UIHelper.layout(view: bottomBlurView, below: voiceOverBlurView, distance: 8)
            UIHelper.createConstraints([.left, .right], between: voiceOverBlurView, and: bottomBlurView, constant: 0)
            UIView.animate(withDuration: 0.3) {
                self.voiceOverBlurView.alpha = 1
            }
        }
        else {
            timeBetweenPredictions = 0.5
            readOutPrediction = false
            voiceOverSwitch.isOn = false
            self.voiceOverBlurView.alpha = 1
            UIView.animate(withDuration: 0.3, animations: {
                self.voiceOverBlurView.alpha = 0
            }) { (completed: Bool) in
                if completed {
                    self.voiceOverBlurView.removeFromSuperview()
                }
            }
        }
    }
    
    
    override public func viewDidLayoutSubviews() {
        self.videoPreviewLayer?.frame = self.cameraPreviewView.bounds
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .high
        
        guard let rearCamera = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: .video, position: .back).devices.first else {
            // TODO: Error Handling
            print("Unable to access the rear camera")
            return
        }
        
        do {
            let cameraInput = try AVCaptureDeviceInput(device: rearCamera)
            
            videoOutput = AVCaptureVideoDataOutput()
            
            if captureSession.canAddInput(cameraInput) && captureSession.canAddOutput(videoOutput) {
                captureSession.addInput(cameraInput)
                captureSession.addOutput(videoOutput)
                videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoDataQueue"))
            }
            
            let captureConnection = videoOutput.connection(with: .video)
            // Always process the frames
            captureConnection?.isEnabled = true
            
            setupCameraView()
        }
        catch let error  {
            print("Unable to access rear camera:  \(error.localizedDescription)")
        }
        handlePlaygroundOptions()
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.captureSession.stopRunning()
    }
    
    func handlePlaygroundOptions() {
        self.videoPreviewLayer?.isHidden = false
        self.modelInfoButton.isHidden = false
        self.changeModelButton.isHidden = false
        self.topBlurView.isHidden = false
        showPredictions = true
        if !currentPlaygroundOptions.contains(.all) {
            for playgroundOption in currentPlaygroundOptions {
                switch playgroundOption {
                case .noCamera:
                    self.videoPreviewLayer?.isHidden = true
//                    DispatchQueue.global(qos: .userInitiated).async {
//                        self.captureSession?.stopRunning()
//                    }
                    break
                case .noModelInfo:
                    self.modelInfoButton.isHidden = true
                case .noChangingModel:
                    self.changeModelButton.isHidden = true
                case .noModelName:
                    self.topBlurView.isHidden = true
                case .noPredictions:
                    showPredictions = false
                    self.modelNameLabel.text = "No Model Selected"
                    self.actualClassLabel.text = "Nothing"
                    self.actualClassLabel.accessibilityHint = self.actualClassLabel.text
                    self.probabilityLabel.text = "100% Confident"
                default:
                    break
                }
            }
        }
    }
    
    func setupCameraView() {
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        
        videoPreviewLayer.videoGravity = .resizeAspectFill
        videoPreviewLayer.connection?.videoOrientation = transformOrientation(orientation: interfaceOrientation)
        cameraPreviewView.layer.addSublayer(videoPreviewLayer)
        
        DispatchQueue.global(qos: .userInitiated).async {
            self.captureSession.startRunning()
            DispatchQueue.main.async {
                self.videoPreviewLayer.frame = self.cameraPreviewView.bounds
            }
        }
    }
    
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        print(Date().timeIntervalSince(timeOfLastCheck))
        self.videoPreviewLayer?.connection?.videoOrientation = transformOrientation(orientation: interfaceOrientation)
        if Date().timeIntervalSince(timeOfLastCheck) > timeBetweenPredictions {
            timeOfLastCheck = Date()
            if showPredictions {
                let request = VNCoreMLRequest(model: customModel) { (finishedRequest, error) in
                    guard let results = finishedRequest.results as? [VNClassificationObservation] else { return }
                    guard let observation = results.first else { return }
                    
                    DispatchQueue.main.async(execute: {
                        if (observation.confidence * 100) >= self.confidenceThreshold {
                            self.actualClassLabel.text = "\(observation.identifier)"
                            self.actualClassLabel.accessibilityHint = self.actualClassLabel.text
                            self.probabilityLabel.text = "\(Int((observation.confidence * 100).rounded()))% Confident"
                            self.probabilityLabel.accessibilityHint = self.probabilityLabel.text
                            if self.readOutPrediction {
                                self.timeBetweenPredictions = 3
                                if self.lastTypeDetected != self.actualClassLabel.text {
                                    self.lastTypeDetected = self.actualClassLabel.text!
                                    UIAccessibility.post(notification: .announcement, argument: "Detected " + self.lastTypeDetected + " with \(Int((observation.confidence * 100).rounded()))% Confidence" )
                                    self.timeBetweenPredictions = 5
                                }
                            }
                        }
                        else {
                            self.actualClassLabel.text = "Nothing Recognized"
                            self.actualClassLabel.accessibilityHint = self.actualClassLabel.text
                            self.probabilityLabel.text = "--% Confident"
                            self.probabilityLabel.accessibilityHint = self.probabilityLabel.text
                            if self.readOutPrediction {
                                self.timeBetweenPredictions = 3
                                if self.lastTypeDetected != self.actualClassLabel.text {
                                    self.lastTypeDetected = self.actualClassLabel.text!
                                    UIAccessibility.post(notification: .announcement, argument: "Nothing Recognized")
                                    self.timeBetweenPredictions = 5
                                }
                            }
                        }
                    })
                }
                guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
                
                // executes request
                try? VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:]).perform([request])
            }
        }
    }
    
    func transformOrientation(orientation: UIInterfaceOrientation) -> AVCaptureVideoOrientation {
        switch orientation {
        case .landscapeLeft:
            return .landscapeLeft
        case .landscapeRight:
            return .landscapeRight
        case .portraitUpsideDown:
            return .portraitUpsideDown
        default:
            return .portrait
        }
    }
    
    // MARK: - Buttons
    @objc func infoButtonPressed(sender: UIButton?) {
        let infoVC = ModelInfoViewController()
        infoVC.modalPresentationStyle = .popover
        infoVC.popoverPresentationController?.sourceRect = sender!.convert(sender!.bounds, to: self.view)
        infoVC.popoverPresentationController?.sourceView = self.view
        infoVC.modelInfo = selectedModel
        self.present(infoVC, animated: true, completion: nil)
    }
    
    @objc func changeModelButtonPressed(sender: UIButton?) {
        let changeModelActionSheet = UIAlertController(title: "Change Model", message: "Here are a few models I've built to let you play around. Tap one to select it!", preferredStyle: .actionSheet)
        for model in defaultModels {
            let thisModelButton = UIAlertAction(title: model.modelName, style: .default) { (thisModelButton) in
                self.changeModel(model: model)
            }
            changeModelActionSheet.addAction(thisModelButton)
        }
        changeModelActionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        changeModelActionSheet.popoverPresentationController?.sourceRect = sender!.convert(sender!.bounds, to: self.view)
        changeModelActionSheet.popoverPresentationController?.sourceView = self.view
        self.present(changeModelActionSheet, animated: true) {
            print(changeModelActionSheet.view.frame)
        }
    }
    
    @objc func voiceOverSwitchedChanged(sender: UISwitch) {
        self.readOutPrediction = sender.isOn
    }
    
    // MARK: - Playground Communication
    open func receive(_ message: PlaygroundValue) {
        guard case let PlaygroundValue.dictionary(messageDictionary) = message else {
            return
        }
        
        guard let messageValue = messageDictionary["message"], case let PlaygroundValue.string(message) = messageValue else {
            return
        }
        
        switch message {
        case "newModel":
            guard let modelURLValue = messageDictionary["modelURL"], case let PlaygroundValue.string(modelURLString) = modelURLValue else {
                return
            }
            
            guard let isCompliedValue = messageDictionary["isCompiled"], case let PlaygroundValue.boolean(isCompiled) = isCompliedValue else {
                return
            }
            let modelURL = URL(fileURLWithPath: modelURLString)
            
            guard let modelNameValue = messageDictionary["modelName"], case let PlaygroundValue.string(modelName) = modelNameValue else {
                return
            }
            
            guard let containsAuthorValue = messageDictionary["containsAuthor"], case let PlaygroundValue.boolean(containsAuthor) = containsAuthorValue else {
                return
            }
            
            guard let containsClassesValue = messageDictionary["containsClasses"], case let PlaygroundValue.boolean(containsClasses) = containsClassesValue else {
                return
            }
            var modelStringClasses: [String]?
            if containsClasses {
                guard let classesValue = messageDictionary["modelClasses"], case let PlaygroundValue.array(modelClasses) = classesValue else {
                    return
                }
                modelStringClasses = [String]()
                for thisClass in modelClasses {
                    guard case let PlaygroundValue.string(thisStringClass) = thisClass else {
                        continue
                    }
                    modelStringClasses!.append(thisStringClass)
                }
            }
            
            guard let confidenceValue = messageDictionary["confidence"], case let PlaygroundValue.floatingPoint(confidenceThreshold) = confidenceValue else {
                return
            }
            
            var modelInfo = MLModelInfo(modelName: modelName, modelURL: modelURL, isCompiled: isCompiled, classNames: modelStringClasses, confidenceThreshold: Float(confidenceThreshold))
            
            if containsAuthor {
                guard let authorNameValue = messageDictionary["authorName"], case let PlaygroundValue.string(authorName) = authorNameValue else {
                    return
                }
                modelInfo.setAuthorName(authorName)
            }
            
            changeModel(model: modelInfo)
        case "replaceOptions":
            guard let optionsValue = messageDictionary["options"], case let PlaygroundValue.array(options) = optionsValue else {
                return
            }
            currentPlaygroundOptions = []
            for thisOption in options {
                guard case let PlaygroundValue.integer(thisIntOption) = thisOption else {
                    continue
                }
                currentPlaygroundOptions.append(PlaygroundCameraOptions(rawValue: thisIntOption)!)
            }
            handlePlaygroundOptions()
        default:
            break
        }
    }
    
    // MARK: - CoreML
    public func changeModel(model: MLModelInfo) {
        var thisModel = model
        if !thisModel.isCompiled {
            do {
                thisModel.modelURL = try MLModel.compileModel(at: thisModel.modelURL)
                thisModel.isCompiled = true
            }
            catch {
                // TODO: Error Handling
            }
        }

        guard let mlModel = try? MLModel(contentsOf: thisModel.modelURL) else {
            // TODO: Error Handling
            return
        }
        guard let compiledModel = try? VNCoreMLModel(for: mlModel) else {
            // TODO: Error Handling
            return
        }
        thisModel.addModelDescription(mlModel.modelDescription)
        self.selectedModel = thisModel
        self.modelNameLabel.text = thisModel.modelName
        self.modelNameLabel.accessibilityHint = self.modelNameLabel.text
        self.customModel = compiledModel
        self.confidenceThreshold = thisModel.confidenceThreshold
    }
}
