//
//  MLModelInfo.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/6/19.
//

import Foundation
import CoreML

public struct MLModelInfo {
    
    var modelName: String!
    var modelURL: URL!
    var isCompiled: Bool!
    var classNames: [String]?
    var confidenceThreshold: Float!
    
    var authorName: String?
    var modelDescription: String?
    var modelVersion: String?
    
    public init(modelName: String, modelURL: URL, isCompiled: Bool, classNames: [String]?, confidenceThreshold: Float) {
        self.modelName = modelName
        self.modelURL = modelURL
        self.isCompiled = isCompiled
        self.classNames = classNames
        self.confidenceThreshold = confidenceThreshold
    }
    
    public mutating func addModelDescription(_ modelDescription: MLModelDescription) {
        if self.authorName == nil {
            self.authorName = (modelDescription.metadata[.author] as! String)
        }
        self.modelDescription = (modelDescription.metadata[.description] as! String)
        self.modelVersion = (modelDescription.metadata[.versionString] as! String)
    }
    
    public mutating func setAuthorName(_ authorName: String?) {
        self.authorName = authorName
    }
}
