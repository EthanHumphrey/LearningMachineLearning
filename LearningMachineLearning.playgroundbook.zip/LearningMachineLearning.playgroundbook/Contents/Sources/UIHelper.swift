//
//  UIHelper.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/12/19.
//

import Foundation
import UIKit

public class UIHelper {
    // MARK: - AutoLayout Helpers
    public static func createConstraints(_ constraints: [NSLayoutConstraint.Attribute], between firstView: UIView, and secondView: UIView, constant: CGFloat) {
        var layoutConstraints = [NSLayoutConstraint]()
        for attribute in constraints {
            var fixedConstant = constant
            if attribute == .bottom || attribute == .right {
                fixedConstant = -constant
            }
            let thisLayoutConstraint = NSLayoutConstraint(item: firstView, attribute: attribute, relatedBy: .equal, toItem: secondView, attribute: attribute, multiplier: 1, constant: fixedConstant)
            layoutConstraints.append(thisLayoutConstraint)
        }
        firstView.superview?.addConstraints(layoutConstraints)
        firstView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    public static func createConstraints(between firstView: UIView, and secondView: UIView, constant: CGFloat) {
        createConstraints([.top, .bottom, .left, .right, .centerX, .centerY], between: firstView, and: secondView, constant: constant)
    }
    
    public static func createHeightConstraint(_ height: CGFloat, for view: UIView) {
        view.superview?.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: height))
    }
    
    public static func createWidthConstraint(_ width: CGFloat, for view: UIView) {
        view.superview?.addConstraint(NSLayoutConstraint(item: view, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: width))
    }
    
    public static func layout(view firstView: UIView, below secondView: UIView, distance: CGFloat) {
        let thisLayoutConstraint = NSLayoutConstraint(item: firstView, attribute: .top, relatedBy: .equal, toItem: secondView, attribute: .bottom, multiplier: 1, constant: distance)
        firstView.superview?.addConstraint(thisLayoutConstraint)
        firstView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    public static func layout(view firstView: UIView, above secondView: UIView, distance: CGFloat) {
        let thisLayoutConstraint = NSLayoutConstraint(item: firstView, attribute: .bottom, relatedBy: .equal, toItem: secondView, attribute: .top, multiplier: 1, constant: distance)
        firstView.superview?.addConstraint(thisLayoutConstraint)
        firstView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    public static func layout(view firstView: UIView, leftOf secondView: UIView, distance: CGFloat) {
        let thisLayoutConstraint = NSLayoutConstraint(item: firstView, attribute: .right, relatedBy: .equal, toItem: secondView, attribute: .left, multiplier: 1, constant: distance)
        firstView.superview?.addConstraint(thisLayoutConstraint)
        firstView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    public static func layout(view firstView: UIView, rightOf secondView: UIView, distance: CGFloat) {
        let thisLayoutConstraint = NSLayoutConstraint(item: firstView, attribute: .left, relatedBy: .equal, toItem: secondView, attribute: .right, multiplier: 1, constant: distance)
        firstView.superview?.addConstraint(thisLayoutConstraint)
        firstView.translatesAutoresizingMaskIntoConstraints = false
    }
}
