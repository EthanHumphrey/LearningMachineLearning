//
//  PlaygroundMessageHelper.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 2/27/19.
//

import Foundation
import PlaygroundSupport

public class PlaygroundMessageHelper {
    
    public static func changeModel(model: MLModelInfo) {
        let liveController = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
        
        var messageDict = ["message": PlaygroundValue.string("newModel"), "modelURL": PlaygroundValue.string(model.modelURL.path), "isCompiled": PlaygroundValue.boolean(model.isCompiled), "modelName": PlaygroundValue.string(model.modelName), "containsAuthor": PlaygroundValue.boolean(false), "containsClasses": PlaygroundValue.boolean(false)]
        if model.authorName != nil {
            messageDict["containsAuthor"] = PlaygroundValue.boolean(true)
            messageDict["authorName"] = PlaygroundValue.string(model.authorName!)
        }
        if model.classNames != nil {
            messageDict["containsClasses"] = PlaygroundValue.boolean(true)
            var convertedClasses = [PlaygroundValue]()
            
            for thisClass in model.classNames! {
                convertedClasses.append(PlaygroundValue.string(thisClass))
            }
            messageDict["modelClasses"] = PlaygroundValue.array(convertedClasses)
        }
        
        messageDict["confidence"] = PlaygroundValue.floatingPoint(Double(model.confidenceThreshold))
        
        liveController?.send(PlaygroundValue.dictionary(messageDict))
    }
    
    public static func setCameraOptions(_ options: [PlaygroundCameraOptions]) {
        let liveController = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
        
        var convertedOptions = [PlaygroundValue]()
        
        for thisOption in options {
            convertedOptions.append(PlaygroundValue.integer(thisOption.rawValue))
        }
        
        let messageDict = ["message": PlaygroundValue.string("replaceOptions"), "options": PlaygroundValue.array(convertedOptions)]
        
        liveController?.send(PlaygroundValue.dictionary(messageDict))
    }
    
    public static func startFakeTraining(withModel model: PrebuiltModelType, withModelName modelName: String) {
        let liveController = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
        
        let messageDict = ["message": PlaygroundValue.string("startTraining"), "model": PlaygroundValue.integer(model.rawValue), "modelName": PlaygroundValue.string(modelName)]
        
        liveController?.send(PlaygroundValue.dictionary(messageDict))
    }
    
}
