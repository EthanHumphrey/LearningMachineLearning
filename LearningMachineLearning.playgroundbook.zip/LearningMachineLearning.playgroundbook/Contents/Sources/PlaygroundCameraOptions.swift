//
//  PlaygroundCameraOptions.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/13/19.
//

import Foundation

public enum PlaygroundCameraOptions: Int {
    case all
    case noCamera
    case noChangingModel
    case noModelInfo
    case noPredictions
    case noModelName
}
