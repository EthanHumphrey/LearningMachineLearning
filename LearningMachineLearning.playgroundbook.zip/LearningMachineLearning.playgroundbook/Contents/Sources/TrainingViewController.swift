//
//  TrainingViewController.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/18/19.
//

import UIKit
import PlaygroundSupport

public class TrainingViewController: UIViewController, PlaygroundLiveViewMessageHandler {
    
    let topView: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 0.9253895879, green: 0.9255481362, blue: 0.9253795743, alpha: 1)
        view.clipsToBounds = true
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 2
        view.layer.borderColor = #colorLiteral(red: 0.7491083741, green: 0.7409707904, blue: 0.7532382607, alpha: 1)
        return view
    }()
    
    let classiferNameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.text = "ImageClassifier"
        label.textAlignment = .left
        return label
    }()
    
    let modelIconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = #imageLiteral(resourceName: "mlModelIcon.png")
        return imageView
    }()
    
    let centerView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 400, height: 300))
        view.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0)
        view.clipsToBounds = true
        view.layer.cornerRadius = 10
        
        // Border Setup
        let shapeLayer = CAShapeLayer()
        let shapeRect = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        
        shapeLayer.bounds = shapeRect
        shapeLayer.position = CGPoint(x: view.frame.width/2, y: view.frame.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = #colorLiteral(red: 0.7491083741, green: 0.7409707904, blue: 0.7532382607, alpha: 1)
        shapeLayer.lineWidth = 2
        shapeLayer.lineJoin = CAShapeLayerLineJoin.round
        shapeLayer.lineDashPattern = [12,9]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 10).cgPath
        
        view.layer.addSublayer(shapeLayer)
        
        return view
    }()
    
    let centerLabel: UILabel = {
        let label = UILabel()
        label.textColor = #colorLiteral(red: 0.7293313146, green: 0.7294581532, blue: 0.7293233275, alpha: 1)
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.text = "No Images To Train On"
        label.textAlignment = .center
        return label
    }()
    
    let centerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.image = #imageLiteral(resourceName: "mechanical1.jpg")
        imageView.isHidden = true
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 10
        return imageView
    }()
    
    let trainingProgressView: UIProgressView = {
        let progressView = UIProgressView()
        progressView.tintColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        progressView.trackTintColor = #colorLiteral(red: 0.9018625617, green: 0.902017355, blue: 0.9018527865, alpha: 1)
        progressView.clipsToBounds = true
        progressView.layer.cornerRadius = 5
        progressView.isHidden = true
        return progressView
    }()
    
    var trainingImages = [UIImage]()
    var writingToolsImages = [#imageLiteral(resourceName: "pen1.jpg"), #imageLiteral(resourceName: "pen2.jpg"), #imageLiteral(resourceName: "pen3.jpg"), #imageLiteral(resourceName: "pencil1.jpg"), #imageLiteral(resourceName: "pencil2.png"), #imageLiteral(resourceName: "pencil3.jpg"), #imageLiteral(resourceName: "mechanical1.jpg"), #imageLiteral(resourceName: "mechanical2.jpg"), #imageLiteral(resourceName: "mechanical3.jpeg"), #imageLiteral(resourceName: "applePencil1.jpg"), #imageLiteral(resourceName: "applePencil2.jpg"), #imageLiteral(resourceName: "applePencil3.jpeg")]
    var fruitImages = [#imageLiteral(resourceName: "apple1.png"), #imageLiteral(resourceName: "apple2.jpg"), #imageLiteral(resourceName: "apple3.jpeg"), #imageLiteral(resourceName: "banana1.jpeg"), #imageLiteral(resourceName: "banana2.jpg"), #imageLiteral(resourceName: "banana3.jpeg"), #imageLiteral(resourceName: "grape1.jpeg"), #imageLiteral(resourceName: "grape2.jpg"), #imageLiteral(resourceName: "grape3.jpg"), #imageLiteral(resourceName: "orange1.jpg"), #imageLiteral(resourceName: "orange2.jpg"), #imageLiteral(resourceName: "orange3.jpg"), #imageLiteral(resourceName: "strawberry1.jpg"), #imageLiteral(resourceName: "strawberry2.jpg"), #imageLiteral(resourceName: "strawberry3.jpg")]
    var isAnimatingImages = false
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = #colorLiteral(red: 0.9685223699, green: 0.9686879516, blue: 0.9685119987, alpha: 1)
        self.view.addSubview(topView)
        UIHelper.createConstraints([.top], between: topView, and: self.view, constant: 30)
        UIHelper.createHeightConstraint(82, for: topView)
        UIHelper.createWidthConstraint(400, for: topView)
        UIHelper.createConstraints([.centerX], between: topView, and: self.view, constant: 0)
        
        topView.addSubview(modelIconImageView)
        UIHelper.createHeightConstraint(50, for: modelIconImageView)
        UIHelper.createWidthConstraint(50, for: modelIconImageView)
        UIHelper.createConstraints([.left, .top, .bottom], between: modelIconImageView, and: topView, constant: 16)
        
        topView.addSubview(classiferNameLabel)
        UIHelper.createConstraints([.right, .top, .bottom], between: classiferNameLabel, and: topView, constant: 16)
        UIHelper.layout(view: classiferNameLabel, rightOf: modelIconImageView, distance: 8)
        
        self.view.addSubview(centerView)
        UIHelper.layout(view: centerView, below: topView, distance: 8)
        UIHelper.createHeightConstraint(300, for: centerView)
        UIHelper.createWidthConstraint(400, for: centerView)
        UIHelper.createConstraints([.centerX], between: centerView, and: self.view, constant: 0)
        
        centerView.addSubview(centerLabel)
        UIHelper.createConstraints(between: centerLabel, and: centerView, constant: 0)
        
        self.view.addSubview(centerImageView)
        UIHelper.createConstraints(between: centerImageView, and: centerView, constant: 0)
        
        self.view.addSubview(trainingProgressView)
        UIHelper.layout(view: trainingProgressView, below: centerLabel, distance: 30)
        UIHelper.createHeightConstraint(10, for: trainingProgressView)
        UIHelper.createConstraints([.left, .right], between: trainingProgressView, and: centerView, constant: 50)
        
//        let startButton = UIButton()
//        startButton.setTitle("Test Training", for: .normal)
//        startButton.frame = CGRect(x: 0, y: 0, width: 50, height: 20)
//        startButton.setTitleColor(UIColor.purple, for: .normal)
//        self.view.addSubview(startButton)
//        UIHelper.layout(view: startButton, below: trainingProgressView, distance: 50)
//        UIHelper.createConstraints([.centerX], between: startButton, and: self.view, constant: 0)
//        startButton.addTarget(self, action: #selector(simiulateTraining), for: .touchUpInside)
        trainingImages = writingToolsImages
    }
    
    @objc func simiulateTraining() {
        trainingProgressView.setProgress(0, animated: false)
        trainingProgressView.isHidden = false
        centerImageView.isHidden = false
        self.isAnimatingImages = true
        changeImages()
        UIView.animate(withDuration: 7, delay: 1, options: .curveLinear, animations: {
            self.trainingProgressView.setProgress(1, animated: true)
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
            self.isAnimatingImages = false
            self.centerLabel.text = "Successfully Trained Model"
            
            let originalFrame = self.centerImageView.frame
            UIView.animate(withDuration: 0.5, animations: {
                self.centerImageView.frame = self.topView.convert(self.modelIconImageView.frame, to: self.view)
                UIView.transition(with: self.centerImageView, duration: 0.5, options: .transitionCrossDissolve, animations: {
                    self.centerImageView.image = self.modelIconImageView.image
                }, completion: nil)
            }, completion: { (completed: Bool) in
                self.centerImageView.isHidden = true
                self.centerImageView.frame = originalFrame
                self.trainingProgressView.setProgress(0, animated: false)
                self.trainingProgressView.isHidden = true
            })
        }
    }
    
    func changeImages() {
        self.centerImageView.image = self.trainingImages[Int.random(in: 0 ..< self.trainingImages.count)]
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            if self.isAnimatingImages {
                self.changeImages()
            }
        }
    }
    
    // MARK: - Playground Communication
    open func receive(_ message: PlaygroundValue) {
        guard case let PlaygroundValue.dictionary(messageDictionary) = message else {
            return
        }
        
        guard let messageValue = messageDictionary["message"], case let PlaygroundValue.string(message) = messageValue else {
            return
        }
        
        switch message {
        case "startTraining":
            guard let modelIntValue = messageDictionary["model"], case let PlaygroundValue.integer(modelInt) = modelIntValue else {
                // TODO: Error Handling
                return
            }
            let thisModel = PrebuiltModelType(rawValue: modelInt)!
            
            guard let modelNameValue = messageDictionary["modelName"], case let PlaygroundValue.string(modelName) = modelNameValue else {
                // TODO: Error Handling
                return
            }
            
            self.classiferNameLabel.text = modelName
            
            switch thisModel {
            case .dogModel:
                break
            case .fruitModel:
                trainingImages = fruitImages
            case .writingToolsModel:
                trainingImages = writingToolsImages
            }
            self.simiulateTraining()
        default:
            break
        }
    }

}
