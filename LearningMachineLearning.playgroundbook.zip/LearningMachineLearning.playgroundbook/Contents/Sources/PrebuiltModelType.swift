//
//  PrebuiltModelType.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/19/19.
//

import Foundation

public enum PrebuiltModelType: Int {
    case dogModel
    case fruitModel
    case writingToolsModel
}
