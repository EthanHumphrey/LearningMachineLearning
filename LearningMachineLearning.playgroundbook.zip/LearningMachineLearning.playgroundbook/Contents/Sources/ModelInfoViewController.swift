//
//  ModelInfoViewController.swift
//  Book_Sources
//
//  Created by Ethan Humphrey on 3/12/19.
//

import UIKit

class ModelInfoViewController: UIViewController {
    
    var modelInfo: MLModelInfo! = nil
    
    let modelNameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 25, weight: .semibold)
        label.text = "Model Name"
        label.accessibilityHint = "Model Name"
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    let modelAuthorLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 20, weight: .regular)
        label.text = "Model Author"
        label.accessibilityHint = "Model Author"
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    let modelVersionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        label.text = "Model Version: 2.0"
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    let descriptionHeaderLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.text = "Description:"
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    let modelDescriptionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        label.text = "Model Description"
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    let classesHeaderLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 20, weight: .semibold)
        label.text = "Categories:"
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    let modelClassesLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.black
        label.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        label.text = "1\n2\n3\n"
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        if modelInfo != nil {
            self.view.addSubview(modelNameLabel)
            UIHelper.createConstraints([.top, .left, .right], between: modelNameLabel, and: self.view, constant: 16)
            modelNameLabel.text = modelInfo.modelName
            
            if let authorName = modelInfo.authorName {
                self.view.addSubview(modelAuthorLabel)
                UIHelper.layout(view: modelAuthorLabel, below: modelNameLabel, distance: 8)
                UIHelper.createConstraints([.left, .right], between: modelAuthorLabel, and: self.view, constant: 16)
                modelAuthorLabel.text = authorName
                
                self.view.addSubview(modelVersionLabel)
                UIHelper.layout(view: modelVersionLabel, below: modelAuthorLabel, distance: 8)
                UIHelper.createConstraints([.left, .right], between: modelVersionLabel, and: self.view, constant: 16)
                modelVersionLabel.text = "Model Version: " + modelInfo.modelVersion!
                
                self.view.addSubview(descriptionHeaderLabel)
                UIHelper.layout(view: descriptionHeaderLabel, below: modelVersionLabel, distance: 8)
                UIHelper.createConstraints([.left, .right], between: descriptionHeaderLabel, and: self.view, constant: 16)
                
                self.view.addSubview(modelDescriptionLabel)
                UIHelper.layout(view: modelDescriptionLabel, below: descriptionHeaderLabel, distance: 8)
                UIHelper.createConstraints([.left, .right], between: modelDescriptionLabel, and: self.view, constant: 16)
                modelDescriptionLabel.text = modelInfo.modelDescription
                
                if let modelClasses = modelInfo.classNames {
                    self.view.addSubview(classesHeaderLabel)
                    UIHelper.layout(view: classesHeaderLabel, below: modelDescriptionLabel, distance: 8)
                    UIHelper.createConstraints([.left, .right], between: classesHeaderLabel, and: self.view, constant: 16)
                    
                    self.view.addSubview(modelClassesLabel)
                    UIHelper.layout(view: modelClassesLabel, below: classesHeaderLabel, distance: 8)
                    UIHelper.createConstraints([.left, .right], between: modelClassesLabel, and: self.view, constant: 16)
                    modelClassesLabel.text = ""
                    modelClassesLabel.accessibilityLabel = ""
                    for thisClassName in modelClasses {
                        modelClassesLabel.text! += thisClassName + "\n"
                        modelClassesLabel.accessibilityLabel! += thisClassName + ",\n"
                    }
                }
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        let extraDistance = self.view.frame.height - modelClassesLabel.frame.maxY
        var currentSize = self.view.frame.size
        currentSize.height = self.view.frame.height - extraDistance
        preferredContentSize = currentSize
    }
}
