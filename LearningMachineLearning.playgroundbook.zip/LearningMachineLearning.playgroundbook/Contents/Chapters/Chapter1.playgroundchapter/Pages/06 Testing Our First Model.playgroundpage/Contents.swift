//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import Foundation
import PlaygroundSupport
import CoreML
import UIKit

var customModelName = "Writing Tools Classifier"
var authorName: String?

if let keyValue = PlaygroundKeyValueStore.current["writingToolsName"],
    case .string(let modelName) = keyValue {
    customModelName = modelName
}
if let keyValue = PlaygroundKeyValueStore.current["writingToolsAuthor"],
    case .string(let modelAuthorName) = keyValue {
    authorName = modelAuthorName
}

let yourModelURL = Bundle.main.url(forResource: "WritingToolsClassifier", withExtension: "mlmodelc")!
var writingToolsModelInfo = MLModelInfo(modelName: customModelName, modelURL: yourModelURL, isCompiled: true, classNames: ["Apple Pencil", "Mechanical Pencil", "Pen", "Pencil"], confidenceThreshold: 80.0)
writingToolsModelInfo.setAuthorName(authorName)

let dogModelURL = Bundle.main.url(forResource: "DogClassifier", withExtension: "mlmodelc")!
let dogModelInfo = MLModelInfo(modelName: "Dog Breed Classifier", modelURL: dogModelURL, isCompiled: true, classNames: ["Chihuahua", "Cocker Spaniel", "Dalmation", "German Shepherd", "Golden Retriever", "Greyhound", "Labrador Retriever", "Poodle", "Pug", "Shih Tzu"], confidenceThreshold: 70.0)

//#-end-hidden-code
/*:
 # Time to test it!
 Now that you've made your own [machine learning model](glossary://machine%20learning%20model), let's try it out!
 
 * callout(Goal:):
 Replace the dog model with your new model!
 
 Press "Run my Code" when you're finished.
 */

// A variable for the dog model 🐶
let dogModel = try? MLModel(contentsOf: dogModelURL)

// The model that YOU just made! ✏️
let yourModel = try? MLModel(contentsOf: yourModelURL)

func getModel() -> MLModel? {
    // Here we need to return the model we want to use
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, yourModel, dogModel)
    //#-code-completion(keyword, show, return)
    //#-editable-code
    return dogModel
    //#-end-editable-code
}
//#-hidden-code
let userReturnedModel = getModel()
if userReturnedModel == yourModel {
    PlaygroundMessageHelper.setCameraOptions([.noChangingModel])
    PlaygroundMessageHelper.changeModel(model: writingToolsModelInfo)
    PlaygroundPage.current.assessmentStatus = .pass(message: "👍 Good Job! Try playing around with your model now! \n\n ...Wait, 🤨 it doesn't really perform that well, what's wrong? \n\n[Let's find out](@next)")
}
else if userReturnedModel == dogModel {
    PlaygroundMessageHelper.setCameraOptions([.noChangingModel])
    PlaygroundMessageHelper.changeModel(model: dogModelInfo)
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["😕 Hmm, you returned the dog model 🐶. Try again."], solution: "Type 'return yourModel' into the text box")
}
else {
    PlaygroundMessageHelper.setCameraOptions([.noPredictions, .noChangingModel])
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["😕 Hmm, you didn't return the model correctly. Try again."], solution: "Type 'return yourModel' into the text box")
}
//#-end-hidden-code
