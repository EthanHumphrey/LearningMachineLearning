//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import Foundation
import PlaygroundSupport
import CoreML
import UIKit

var trueTrainingData = [UIImage]()
let correctCategoryNames = ["Pencil", "Pen", "Mechanical Pencil", "Apple Pencil"]

public class MLImageClassifier {
    private let trainingData: DataSource!
    
    init (trainingData: DataSource) {
        self.trainingData = trainingData
    }
    
    func startTraining(withModelName modelName: String, withAuthorName authorName: String) {
        if trainingData.dataDict.count == correctCategoryNames.count {
            var classesMatchUp = true
            for thisEntry in trainingData.dataDict {
                if !correctCategoryNames.contains(thisEntry.key) {
                    classesMatchUp = false
                }
            }
            if classesMatchUp {
                let allTrainingData = trainingData.convertToFullArray()
                var imagesMatchUp = true
                for thisImage in allTrainingData {
                    if !trueTrainingData.contains(thisImage) {
                        imagesMatchUp = false
                    }
                }
                if imagesMatchUp {
                    PlaygroundKeyValueStore.current["writingToolsName"] = .string(modelName)
                    PlaygroundKeyValueStore.current["writingToolsAuthor"] = .string(authorName)
                    PlaygroundMessageHelper.startFakeTraining(withModel: .writingToolsModel, withModelName: modelName)
                    PlaygroundPage.current.assessmentStatus = .pass(message: "😱 Your first ML model is training! 💪 Once it finishes, move on to the next page to try it out! \n\n[Finished Training!](@next)")
                }
                else {
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤔 You got the names of your categories correct, but the images don't match up. Make sure you added them to the right categories."], solution: "The names of the categories should be: Pencil, Pen, Mechanical Pencil, and Apple Pencil")
                }
            }
            else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤔 Hmm, your category names are incorrect. Try checking your spelling. Try again."], solution: "The names of the categories should be: Pencil, Pen, Mechanical Pencil, and Apple Pencil")
            }
        }
        else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤔 Hmm, you added either too many or too few categories to your datasource. Try again."], solution: "Add one category for each of the categories specified. There should be four: Pencil, Pen, Mechanical Pencil, and Apple Pencil")
        }
    }
    
    public class DataSource {
        
        var dataDict = [String: [UIImage]]()
        init() {}
        
        func addCategory(categoryName: String, images: [UIImage]) {
            dataDict[categoryName] = images
        }
        
        func addImage(_ image: UIImage, withCategory categoryName: String) {
            if let categoryImages = dataDict[categoryName] as? [UIImage] {
                dataDict[categoryName]?.append(image)
            }
            else {
                dataDict[categoryName] = [image]
            }
        }
        
        func convertToFullArray() -> [UIImage] {
            var fullArray = [UIImage]()
            for thisEntry in dataDict {
                fullArray.append(contentsOf: thisEntry.value)
            }
            return fullArray
        }
    }
}

//#-end-hidden-code
/*:
 # Okay, but where's the "learning" part of machine learning?
 We've been picturing [machine learning models](glossary://machine%20learning%20model) as sort of "black boxes" which we can give an image and it will give us a label for that image. However, there is a way to make these models ourselves, and we call this *[training](glossary://training)*.
 
 Training a model is super simple thanks to a new framework developed by Apple called Create ML. All we need to do is give the framework at least 10 images for every object type we want it to recognize.
 
 > For the purpose of this exercise, you will only add three images to each [category](glossary://category), as this is a conceptual excercise.
 
 We are going to be training a model to classify different types of writing tools. Our model will be able to classify between the following types:
 - Pencil ✏️
 - Pen ✒️
 - Mechanical Pencil 🤖
 - Apple Pencil 
 
 > Make sure when defining your categories that you use the exact spelling as above! (Without the emojis of course 😉)
 
 # Goals
 1. Use the `addCategory()` method to populate our data into the `DataSource`.
 2. Create an instance of `MLImageClassifier`, passing in the `DataSource` we created.
 3. Use the `startTraining()` method of `MLImageClassifier` to begin training _and absorb all the information on the Internet_.
 4. Name your model something fancy and write your name in the author field! This name will appear next time you use it.
 
 Press "Run my Code" when you're finished.
 */

let penImages = [#imageLiteral(resourceName: "pen1.jpg"), #imageLiteral(resourceName: "pen2.jpg"), #imageLiteral(resourceName: "pen3.jpg")]
let pencilImages = [#imageLiteral(resourceName: "pencil1.jpg"), #imageLiteral(resourceName: "pencil2.png"), #imageLiteral(resourceName: "pencil3.jpg")]
let mechanicalPencilImages = [#imageLiteral(resourceName: "mechanical1.jpg"), #imageLiteral(resourceName: "mechanical2.jpg"), #imageLiteral(resourceName: "mechanical3.jpeg")]
let applePencilImages = [#imageLiteral(resourceName: "applePencil1.jpg"), #imageLiteral(resourceName: "applePencil2.jpg"), #imageLiteral(resourceName: "applePencil3.jpeg")]
//#-hidden-code
trueTrainingData.append(contentsOf: penImages)
trueTrainingData.append(contentsOf: pencilImages)
trueTrainingData.append(contentsOf: mechanicalPencilImages)
trueTrainingData.append(contentsOf: applePencilImages)
//#-end-hidden-code

let dataSource = MLImageClassifier.DataSource()

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, convertToFullArray(), dataDict, correctCategoryNames)
//#-editable-code
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)

let modelName = "<#Name it whatever you want!#>"
let authorName = "<#Your name goes here!#>"
//#-end-editable-code

let imageClassifier = MLImageClassifier(trainingData: dataSource)
imageClassifier.startTraining(withModelName: modelName, withAuthorName: authorName)
