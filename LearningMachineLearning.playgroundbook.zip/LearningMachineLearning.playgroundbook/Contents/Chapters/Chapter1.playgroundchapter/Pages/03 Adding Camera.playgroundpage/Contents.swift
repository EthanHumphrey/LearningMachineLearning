//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport

var hasPassed = false
PlaygroundMessageHelper.setCameraOptions([.noCamera, .noChangingModel, .noPredictions])
func showCamera() {
    PlaygroundMessageHelper.setCameraOptions([.noChangingModel, .noPredictions])
    hasPassed = true
}
//#-end-hidden-code
/*:
 # Where's our Camera?
 Now it's time for YOU to build this app! You'll see the app on the right looks a bit dark. Let's fix that!
 
 First we will need to show the camera on the screen. Use the method `showCamera()` to display it on screen.
 
 * callout(Goal:):
 📷 Display the camera feed in our view.
 
 Press "Run my Code" when you're finished.
 */
    
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, showCamera())
// Call the showCamera() method here
//#-editable-code

//#-end-editable-code

//#-hidden-code
if hasPassed {
    PlaygroundPage.current.assessmentStatus = .pass(message: "Good job showing the camera 📸! Now it's time to implement the actual machine learning aspect. \n\n[I'm Ready!](@next)")
}
else {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["😕 Not quite... make sure you called the 'showCamera()' function"], solution: "Type 'showCamera()' into the text box.")
}
//#-end-hidden-code
