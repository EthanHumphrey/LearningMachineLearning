//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import Foundation
import PlaygroundSupport
import CoreML
import UIKit

class MLPrediction {
    let uuid = UUID()
}

var arePredictionsCorrect = false
var createdPrediction: MLPrediction?
let modelURL = Bundle.main.url(forResource: "DogClassifier", withExtension: "mlmodelc")!
let dogModelInfo = MLModelInfo(modelName: "Dog Breed Classifier", modelURL: Bundle.main.url(forResource: "DogClassifier", withExtension: "mlmodelc")!, isCompiled: true, classNames: ["Chihuahua", "Cocker Spaniel", "Dalmation", "German Shepherd", "Golden Retriever", "Greyhound", "Labrador Retriever", "Poodle", "Pug", "Shih Tzu"], confidenceThreshold: 70.0)

PlaygroundMessageHelper.setCameraOptions([.noPredictions, .noChangingModel])

func getPrediction(from image: UIImage) -> MLPrediction {
    createdPrediction = MLPrediction()
    return createdPrediction!
}

func parsePrediction(_ prediction: MLPrediction) {
    if createdPrediction != nil {
        if prediction.uuid == createdPrediction!.uuid {
            arePredictionsCorrect = true
        }
    }
}
//#-end-hidden-code
/*:
 # What's a model?
 The basis of machine learning is what we call a [model](glossary://machine%20learning%20model). Think of this like a black box. We don’t need to understand what the model actually does, just know that it takes an input (our image) and gives an output (what’s in the image).

 When you pointed your camera at a dog in the last page, you were actually sending an image from the camera into the model.
 
 When we send an image into the model, it gives us a [prediction](glossary://prediction). We call the model’s output a prediction because the model is only *predicting* what it thinks is in the image.
 
 To show our prediction in our program, we first need to get an image from the camera and then pass it in to the model.
 
 # Goals
 1. Return the model we are going to be using.
 2. Get a prediction from our ML model using the `getPrediction` function, passing in our camera image as an input. Make sure to save this in its own variable.
 3. Display the prediction in a label by using the `parsePrediction` method, passing in our `MLPrediction` variable.
 4. Look cool while doing it 😎
 
 Press "Run my Code" when you're finished.
 */

// A variable for the dog model 🐶
let dogModel = try? MLModel(contentsOf: modelURL)

func getModel() -> MLModel? {
    // Here we need to return the model we want to use
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, dogModel)
    //#-code-completion(keyword, show, return)
    //#-editable-code
    return nil
    //#-end-editable-code
}

// Called every time the camera updates
func captureOutput(cameraImage: UIImage) {
    // Pass the camera image through to the model, and then pass the prediction
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, getPrediction(from:), parsePrediction(:), cameraImage, prediction)
    //#-editable-code
    let prediction: MLPrediction = getPrediction(from: <#UIImage#>)
    parsePrediction(<#MLPrediction#>)
    //#-end-editable-code
}
//#-hidden-code
captureOutput(cameraImage: UIImage())
if getModel() == dogModel {
    PlaygroundMessageHelper.changeModel(model: dogModelInfo)
    if arePredictionsCorrect {
            PlaygroundMessageHelper.setCameraOptions([.noChangingModel])
            PlaygroundPage.current.assessmentStatus = .pass(message: "🤩 Your machine learning program is really coming along! We're not finished yet though... 🤨 \n\n[What's Next?](@next)")
    }
    else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["Good job returning the model, but something went wrong when getting the prediction. 🤔"], solution: "Pass 'cameraImage' into the getPrediction function, and pass its return into the parsePrediction")
    }
}
else {
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤨 Hmm, you didn't return the model correctly. Try again."], solution: "Type 'return fruitModel' into the first text box")
}
//#-end-hidden-code
