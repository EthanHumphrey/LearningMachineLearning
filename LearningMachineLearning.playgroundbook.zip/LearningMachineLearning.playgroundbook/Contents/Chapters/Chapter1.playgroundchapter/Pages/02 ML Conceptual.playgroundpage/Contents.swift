//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport
PlaygroundPage.current.assessmentStatus = .pass(message: "Great! Hopefully you now understand a bit more about what Machine Learning does! You should have noticed that it's not the most precise, but that's okay! Machine learning is never totally accurate. On a small scale like this playground, it may not always detect anything. Let's start making our own ML program now. 😱 \n\n[Start Creating](@next)")
//#-end-hidden-code
/*:
 # What is Machine Learning?
 
 ![An image of Apple's Create ML framework icon](createMLIcon.png)
 
 [Machine learning](glossary://machine%20learning), commonly shortened to "[ML](glossary://ML)", involves a computer’s ability to process an input and provide an output. This means that you could give a machine learning program an image of a dog and it could tell you what type of dog it is. Try this out on the right to see how the program responds to pointing the camera at various types of dogs.
 
 > If you do not have any dogs with you, try pointing at a picture, or an image on another device.
 
 Press "Run my Code" to move on after you've scanned a few different types of dogs.
 */
