//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import Foundation
import PlaygroundSupport
import CoreML
import UIKit

var trueTrainingData = [UIImage]()
let correctCategoryNames = ["Apple", "Banana", "Grape", "Orange", "Strawberry"]

public class MLImageClassifier {
    let trainingData: DataSource!
    
    init (trainingData: DataSource) {
        self.trainingData = trainingData
    }
    
    func startTraining(withModelName modelName: String, withAuthorName authorName: String) {
        if trainingData.dataDict.count == correctCategoryNames.count {
            var classesMatchUp = true
            for thisEntry in trainingData.dataDict {
                if !correctCategoryNames.contains(thisEntry.key) {
                    classesMatchUp = false
                }
            }
            if classesMatchUp {
                let allTrainingData = trainingData.convertToFullArray()
                var imagesMatchUp = true
                for thisImage in allTrainingData {
                    if !trueTrainingData.contains(thisImage) {
                        imagesMatchUp = false
                    }
                }
                if imagesMatchUp {
                    PlaygroundKeyValueStore.current["fruitModelName"] = .string(modelName)
                    PlaygroundKeyValueStore.current["fruitModelAuthor"] = .string(authorName)
                    PlaygroundMessageHelper.startFakeTraining(withModel: .fruitModel, withModelName: modelName)
                    PlaygroundPage.current.assessmentStatus = .pass(message: "😱 Your ML model is training! 💪 Once it finishes, move on to the next page to try it out! \n\n[Finished Training!](@next)")
                }
                else {
                    PlaygroundPage.current.assessmentStatus = .fail(hints: ["😧 You got the names of your categories correct, but the images don't match up. Make sure you added them to the right categories."], solution: "The names of the categories should be: Apple, Banana, Grape, Orange, and Strawberry")
                }
            }
            else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤔 Hmm, your category names are incorrect. Try checking your spelling. Try again."], solution: "The names of the categories should be: Apple, Banana, Grape, Orange, and Strawberry")
            }
        }
        else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤔 Hmm, you added either too many or too few categories to your datasource. Try again."], solution: "Add one category for each of the categories specified. There should be four: Apple, Banana, Grape, Orange, and Strawberry")
        }
    }
    
    public class DataSource {
        
        var dataDict = [String: [UIImage]]()
        init() {}
        
        func addCategory(categoryName: String, images: [UIImage]) {
            dataDict[categoryName] = images
        }
        
        func addImage(_ image: UIImage, withCategory categoryName: String) {
            if let categoryImages = dataDict[categoryName] as? [UIImage] {
                dataDict[categoryName]?.append(image)
            }
            else {
                dataDict[categoryName] = [image]
            }
        }
        
        func convertToFullArray() -> [UIImage] {
            var fullArray = [UIImage]()
            for thisEntry in dataDict {
                fullArray.append(contentsOf: thisEntry.value)
            }
            return fullArray
        }
    }
}

//#-end-hidden-code
/*:
 # What makes a good machine learning model?
 Alright, you may have been a bit misled. While we technically _can_ [train](glossary://training) a [model](glossary://machine%20learning%20model) on any set of images, it may not be the smartest thing to do.
 
 **But why?**
 
 Well, we have to make sure that we train our models on different types of objects. The reason our last model wasn't very accurate is because we chose objects that were very similar to each other. How often have you mistaken a mechanical pencil for a pen, or vice versa? Instead, let's try training a model to recognize fruits.
 
 Specifically, we are going to train a model to recognize the following [categories](glossary://category) of fruits:
 - Apple 🍎
 - Banana 🍌
 - Grape 🍇
 - Orange 🍊
 - Strawberry 🍓
 
 > Make sure when defining your categories that you use the exact spelling as above! (Without the emojis of course 😉)
 
 # Goals
 1. Use the `addCategory()` method to populate our data into the DataSource.
 2. Create an instance of `MLImageClassifier`, passing in the DataSource we created.
 3. Use the `startTraining()` method of `MLImageClassifier` to begin training.
 4. Name your model something fancy and write your name in the author field!
 
 Press "Run my Code" when you're finished.
 */

let appleImages = [#imageLiteral(resourceName: "apple1.png"), #imageLiteral(resourceName: "apple2.jpg"), #imageLiteral(resourceName: "apple3.jpeg")]
let bananaImages = [#imageLiteral(resourceName: "banana1.jpeg"), #imageLiteral(resourceName: "banana2.jpg"), #imageLiteral(resourceName: "banana3.jpeg")]
let grapeImages = [#imageLiteral(resourceName: "grape1.jpeg"), #imageLiteral(resourceName: "grape2.jpg"), #imageLiteral(resourceName: "grape3.jpg")]
let orangeImages = [#imageLiteral(resourceName: "orange1.jpg"), #imageLiteral(resourceName: "orange2.jpg"), #imageLiteral(resourceName: "orange3.jpg")]
let strawberryImages = [#imageLiteral(resourceName: "strawberry1.jpg"), #imageLiteral(resourceName: "strawberry2.jpg"), #imageLiteral(resourceName: "strawberry3.jpg")]
//#-hidden-code
trueTrainingData.append(contentsOf: appleImages)
trueTrainingData.append(contentsOf: bananaImages)
trueTrainingData.append(contentsOf: grapeImages)
trueTrainingData.append(contentsOf: orangeImages)
trueTrainingData.append(contentsOf: strawberryImages)
//#-end-hidden-code

let dataSource = MLImageClassifier.DataSource()
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, convertToFullArray(), dataDict, correctCategoryNames)
//#-editable-code
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)
dataSource.addCategory(categoryName: <#String#>, images: <#[UIImage]#>)

let modelName = "<#Name it whatever you want!#>"
let authorName = "<#Your name goes here!#>"
//#-end-editable-code

let imageClassifier = MLImageClassifier(trainingData: dataSource)
imageClassifier.startTraining(withModelName: modelName, withAuthorName: authorName)
