//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import Foundation
import PlaygroundSupport
import CoreML
import UIKit

var oldCustomModelName = "Writing Tools Classifier"
var oldAuthorName: String?

if let keyValue = PlaygroundKeyValueStore.current["writingToolsName"],
    case .string(let modelName) = keyValue {
    oldCustomModelName = modelName
}
if let keyValue = PlaygroundKeyValueStore.current["writingToolsAuthor"],
    case .string(let modelAuthorName) = keyValue {
    oldAuthorName = modelAuthorName
}

var customModelName = "Fruit Classifier"
var authorName: String?

if let keyValue = PlaygroundKeyValueStore.current["fruitModelName"],
    case .string(let modelName) = keyValue {
    customModelName = modelName
}
if let keyValue = PlaygroundKeyValueStore.current["fruitModelAuthor"],
    case .string(let modelAuthorName) = keyValue {
    authorName = modelAuthorName
}

let dogModelURL = Bundle.main.url(forResource: "DogClassifier", withExtension: "mlmodelc")!
let dogModelInfo = MLModelInfo(modelName: "Dog Breed Classifier", modelURL: dogModelURL, isCompiled: true, classNames: ["Chihuahua", "Cocker Spaniel", "Dalmation", "German Shepherd", "Golden Retriever", "Greyhound", "Labrador Retriever", "Poodle", "Pug", "Shih Tzu"], confidenceThreshold: 70.0)

let yourModelURL = Bundle.main.url(forResource: "WritingToolsClassifier", withExtension: "mlmodelc")!
var writingToolsModelInfo = MLModelInfo(modelName: oldCustomModelName, modelURL: yourModelURL, isCompiled: true, classNames: ["Apple Pencil", "Mechanical Pencil", "Pen", "Pencil"], confidenceThreshold: 80.0)
writingToolsModelInfo.setAuthorName(oldAuthorName)

let fruitModelURL = Bundle.main.url(forResource: "FruitClassifier", withExtension: "mlmodelc")!
var fruitModelInfo = MLModelInfo(modelName: customModelName, modelURL: fruitModelURL, isCompiled: true, classNames: ["Apple", "Banana", "Grape", "Orange", "Strawberry"], confidenceThreshold: 85.0)
fruitModelInfo.setAuthorName(authorName)

//#-end-hidden-code
/*:
 # Time for a change!
 We now have three different [models](glossary://machine%20learning%20model) that we can use for our program, why not add a button to switch between them?
 
 * callout(Goal:):
 Return an array of all the models we've made
 
 Press "Run my Code" when you're finished.
 */

// A variable for the dog model 🐶
let dogModel = try? MLModel(contentsOf: dogModelURL)

// The inaccurate model that you made earlier 👎
let yourModel = try? MLModel(contentsOf: yourModelURL)

// The new fruit model that you just made 🍎
let fruitModel = try? MLModel(contentsOf: fruitModelURL)

func getAvailableModels() -> [MLModel?] {
    // Here we need to return and array of available models
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, yourModel, dogModel, fruitModel)
    //#-code-completion(keyword, show, return)
    //#-editable-code
    
    //#-end-editable-code
}
//#-hidden-code
let correctModels = [dogModel, yourModel, fruitModel]
let availableModels = getAvailableModels()

if availableModels.count == correctModels.count {
    var modelsMatchUp = true
    for thisModel in availableModels {
        if !correctModels.contains(thisModel) {
            modelsMatchUp = false
        }
    }
    if modelsMatchUp {
        PlaygroundMessageHelper.setCameraOptions([.all])
        PlaygroundPage.current.assessmentStatus = .pass(message: "🤯 Good Job! Now you can easily switch between all of our included models. Try it out! \n\n[Awesome!](@next)")
    }
    else {
        PlaygroundMessageHelper.setCameraOptions([.noChangingModel])
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤨 Hmm, you returned the right number of models, but you didn't return the right models. Try again."], solution: "Type `return [dogModel, yourModel, fruitModel]` into the text box")
    }
}
else {
    PlaygroundMessageHelper.setCameraOptions([.noChangingModel])
    PlaygroundPage.current.assessmentStatus = .fail(hints: ["🤨 Hmm, you returned either too many or too few models. Try again."], solution: "Type `return [dogModel, yourModel, fruitModel]` into the text box")
}
//#-end-hidden-code
