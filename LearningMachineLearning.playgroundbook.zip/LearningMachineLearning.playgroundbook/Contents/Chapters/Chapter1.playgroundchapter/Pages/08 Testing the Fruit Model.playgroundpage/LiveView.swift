//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

import UIKit
import PlaygroundSupport

// Instantiate a new instance of the live view from the book's auxiliary sources and pass it to PlaygroundSupport.

let cameraController = CameraViewController()
cameraController.currentPlaygroundOptions = [.noChangingModel]

var oldCustomModelName = "Writing Tools Classifier"
var oldAuthorName: String?

if let keyValue = PlaygroundKeyValueStore.current["writingToolsName"],
    case .string(let modelName) = keyValue {
    oldCustomModelName = modelName
}
if let keyValue = PlaygroundKeyValueStore.current["writingToolsAuthor"],
    case .string(let modelAuthorName) = keyValue {
    oldAuthorName = modelAuthorName
}

let yourModelURL = Bundle.main.url(forResource: "WritingToolsClassifier", withExtension: "mlmodelc")!
var writingToolsModelInfo = MLModelInfo(modelName: oldCustomModelName, modelURL: yourModelURL, isCompiled: true, classNames: ["Apple Pencil", "Mechanical Pencil", "Pen", "Pencil"], confidenceThreshold: 80.0)
writingToolsModelInfo.setAuthorName(oldAuthorName)

cameraController.changeModel(model: writingToolsModelInfo)
PlaygroundPage.current.liveView = cameraController
PlaygroundPage.current.needsIndefiniteExecution = true
