//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import PlaygroundSupport

PlaygroundPage.current.assessmentStatus = .pass(message: "Thanks for learning! 👏")
//#-end-hidden-code
/*:
 # Thank you for experiencing my playground!
 
![Welcome to my playground](LMLicon.png)
 
 Over the course of this playground book you have learned the following:
 - How to show the camera in an app 📷
 - What [machine learning](glossary://machine%20learning) is 🤯
 - How to [train](glossary://training) an [ML model](glossary://machine%20learning) 🧐
 - How to get [predictions](glossary://prediction) from an ML Model about what is in an image 🤓
 
 I hope you have enjoyed my submission for WWDC19! I'll see you at the McEnery Convention Center in June!
 */
